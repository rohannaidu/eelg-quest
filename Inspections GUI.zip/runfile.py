import glob
import inspect_gui
import os

os.chdir("JHK_selection") ### NAVIGATE TO YOUR DIRECTORY HERE
file_list = glob.glob('*new_zfit.png')#'*new_zfit.png'
my_name = 'rpn'     ### CHANGE TO YOUR NAME
x = inspect_gui.ImageClassifier(images=file_list, logfile='inspect_3dhst_%s.info' %(my_name), RGB_PATH='./', RGB_EXTENSION='_vJH_6.png', FITS_PATH='./', load_log=True, ds9=None, rgb_lower=True)
