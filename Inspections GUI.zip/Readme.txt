--> Put runfile.py and inspect_gui.py in the same directory.

--> Point runfile.py to the directory with the zfit, linefit png files by modifying the path in line 5:
os.chdir("YOUR PATH"). A relative path works! Enter your name in line 7.

--> Fire up python and execute "runfile.py". The GUI should appear.

--> Pressing "log to file" writes your marked values to a FITS file ("inspect_3dhst_(yourname).info.fits" ) located in the folder with all the linefits/zfits files. Use the "log to file" button when you wish to save your work. The "Quit" button displays some weird behaviour at this point in the development cycle.

RPN, 20th July 2015